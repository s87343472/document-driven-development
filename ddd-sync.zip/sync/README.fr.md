# Développement Piloté par la Documentation (Document-Driven Development)

[English](README.md) | [简体中文](README.zh-CN.md) | [日本語](README.ja.md) | **Français**

Un skill Claude Code qui apprend à l'IA à vous aider à construire des produits selon une approche pilotée par la documentation.

> Les 15 minutes économisées en sautant la spécification deviennent une facture de 3 heures de débogage. **Lent au départ, rapide sur toute la durée.**

## Table des matières

- [Qu'est-ce que le développement piloté par la documentation ?](#quest-ce-que-le-développement-piloté-par-la-documentation-)
- [La formule centrale](#la-formule-centrale)
- [Le système documentaire](#le-système-documentaire)
- [Installation](#installation)
- [Utilisation](#utilisation)
- [Avant / Après](#avant--après)
- [Principes clés](#principes-clés)
- [Structure du projet](#structure-du-projet)
- [Bonnes pratiques](#bonnes-pratiques)
- [FAQ](#faq)
- [Série d'articles](#série-darticles)
- [Journal des modifications](#journal-des-modifications)

## Qu'est-ce que le développement piloté par la documentation ?

**La documentation est la source unique de vérité. Le code est l'implémentation de la documentation, et non l'inverse.**

Quand vous dites à un agent « fais-moi une page d'inscription », il implémente parfaitement *sa* compréhension — en comblant vos hypothèses tacites (sécurité, cas limites, règles métier) avec les moyennes de ses données d'entraînement. Le langage naturel est ambigu par défaut ; les humains comblent les vides grâce à l'expérience partagée, mais vous et l'agent n'en partagez aucune.

Au lieu de laisser l'IA générer du code à partir d'exigences vagues, ce skill vous guide ainsi :

1. **Réfléchir d'abord** — Clarifier l'intention, le périmètre et les critères de succès
2. **Documenter ensuite** — Créer une documentation structurée
3. **Coder enfin** — Générer le code à partir de spécifications claires

Le livrable n'est pas toujours une application web. Skills, agents, serveurs MCP, outils CLI et méthodologies .md utilisent tous le même système documentaire.

## La formule centrale

```
intent.md  →  roadmap.md  →  spec.md  →  plan.md  →  code
(POURQUOI)    (CHEMIN)       (QUOI)      (COMMENT)
```

- **La génération est bon marché ; l'évolution maîtrisée est rare.** Le goulot d'étranglement n'est plus d'écrire du code, mais de décider ce qui doit exister — et c'est dans les documents que cette décision se prend.
- **Remonter les problèmes jusqu'aux documents.** Quand le code échoue, corrigez la source de vérité, puis régénérez.
- **Décrire ce que vous voulez ≠ définir ce qui doit être construit.** La spécification transforme le premier en second.

## Le système documentaire

| Couche | Fichier | Question | Stabilité |
| ------ | ------- | -------- | --------- |
| Intention | `intent.md` | POURQUOI et POUR QUI | Change rarement |
| Feuille de route | `roadmap.md` | Chemin des versions + colonne vertébrale architecturale invariante | Occasionnellement (produits multi-versions uniquement) |
| Spécification | `spec.md` | QUOI construire | Change par fonctionnalité |
| Plan | `plan.md` | COMMENT implémenter | Change souvent |

Ce sont des documents de conception (build-time). Les produits agentiques peuvent aussi avoir des **documents d'exécution (runtime)** — les fichiers de standard / mémoire / état que le produit lui-même lit et écrit en fonctionnant. Gardez-les versionnés et lisibles par l'humain, afin que l'utilisateur puisse voir, et modifier, la façon dont le produit « pense ». Voir [`principles.md`](skills/document-driven-development/principles.md).

## Installation

### Pour Claude Code

```bash
# Dans votre projet
mkdir -p .claude/skills
cp -r skills/document-driven-development .claude/skills/

# Ou globalement
cp -r skills/document-driven-development ~/.claude/skills/
```

### Pour Claude (Web/API)

Copiez le contenu de `skills/document-driven-development/SKILL.md` (plus `templates.md` et `principles.md` si le contexte le permet) dans votre prompt système ou vos instructions de projet.

## Utilisation

Une fois installé, Claude appliquera cette méthodologie lorsque vous :

- Demandez explicitement de construire un projet avec le DDD
- Demandez d'ajouter des fonctionnalités à un projet existant
- Mentionnez `intent.md`, `spec.md`, `plan.md` ou `roadmap.md`

Remarque : le skill est livré avec `disable-auto-invoke: true` pour éviter les déclenchements intempestifs. Supprimez cette ligne du frontmatter de SKILL.md si vous souhaitez une activation automatique.

## Avant / Après

### Avant : Vibe Coding

```
Vous : Aide-moi à créer un blog personnel
Claude : Bien sûr ! [Génère 500 lignes de code]
Vous : Attends, je voulais plus simple, sans base de données,
       juste des fichiers markdown...
Claude : Ah, je recommence... [500 lignes de plus, toujours pas ça]

# Résultat : itérations multiples, temps perdu, code non conforme aux attentes
```

### Après : Piloté par la documentation

```
Vous : Aide-moi à créer un blog personnel
Claude : Utilisons le développement piloté par la documentation.
  Quelques questions d'abord :
  1. Quel est l'objectif principal ? 2. Qui sont les lecteurs ?
  3. À quoi ressemble « terminé » pour la v0.1 ? 4. Que NE voulez-vous PAS ?

Vous : Des articles techniques, pour des développeurs. La v0.1 doit juste
    afficher du markdown. Pas de commentaires, pas de CMS, pas de BDD.

Claude : [crée intent.md, spec.md, plan.md, puis génère un code ciblé]

# Résultat : bon du premier coup, documenté pour les itérations futures
```

## Principes clés

1. **Documenter d'abord, coder ensuite** — Ne jamais générer de code sans documentation claire
2. **Remonter les problèmes jusqu'aux documents** — Quand le code échoue, vérifier s'il s'agit d'un problème de spec ou de plan
3. **Un objectif central par version** — v0.1, v0.2, v0.3... par petits pas
4. **Garder documents et code synchronisés** — Les committer ensemble
5. **Les documents servent à communiquer** — Écrire pour votre futur vous et pour l'IA
6. **Définir la colonne vertébrale architecturale avant la v0.1** — Nommer ce qui NE changera PAS d'une version à l'autre, pour qu'une v0.1 mince ne soit pas jetable
7. **Chaque version a une porte de validation** — Outils : fonctionne comme spécifié. Produits : rétention, usage ou paiement — pas un simple intérêt. Ne pas avancer tant que la porte n'est pas franchie
8. **Dans les projets agentiques, les documents peuvent être le runtime** — L'agent les lit et les écrit en direct ; gardez-les lisibles par l'humain et versionnés

## Structure du projet

```
document-driven-development/
├── README.md               # English
├── README.zh-CN.md         # 简体中文
├── README.ja.md            # 日本語
├── README.fr.md            # Français (ce fichier)
├── LICENSE
└── skills/
    └── document-driven-development/
        ├── SKILL.md        # Règles de comportement + workflows (cœur économe en contexte)
        ├── templates.md    # Modèles intent / roadmap / spec / plan + exemple
        └── principles.md   # Philosophie, principes 1-8, anti-patterns
```

## Bonnes pratiques

### À faire

- **Commencer par intent.md** — Même 5 lignes valent mieux que rien
- **Expliciter les non-objectifs** — « Pas de comptes utilisateurs » prévient la dérive du périmètre
- **Nommer la colonne vertébrale avant la v0.1** — Les versions suivantes la remplissent, elles ne la reconstruisent pas
- **Garder les versions petites** — La v0.1 doit être réalisable en heures, pas en jours
- **Mettre à jour les documents quand les exigences changent** — Corriger la source de vérité, pas seulement le code
- **Committer documents et code ensemble**

### À éviter

- **Ne pas sauter directement au code** — Résister à l'envie de « juste commencer à coder »
- **Ne pas sur-documenter** — plan.md décrit QUOI atteindre, pas le code exact
- **Ne pas mettre la technique dans spec.md** — « L'utilisateur peut rechercher » (bien) vs « Utiliser Elasticsearch » (à mettre dans plan.md)
- **Ne pas viser la v1.0 immédiatement** — v0.1 → v0.2 → v0.3, c'est la voie
- **Ne pas avancer avec une porte non franchie** — Ce serait construire sur des hypothèses non validées

## FAQ

**Q : N'est-ce pas plus lent que de simplement demander à l'IA d'écrire du code ?**
Pour les tâches triviales, oui. Pour tout ce qui sera itéré, non. Le temps passé sur la documentation est récupéré maintes fois en évitant les boucles « ce n'est pas ce que je voulais ».

**Q : Ai-je besoin de tous les documents ?**
Pour les petits projets, vous pouvez les combiner, et roadmap.md n'a de sens que pour les produits multi-versions. Mais les séparer aide à réfléchir à différents niveaux : POURQUOI → CHEMIN → QUOI → COMMENT.

**Q : Et si mes exigences changent en cours de projet ?**
Mettez d'abord à jour les documents, puis le code. La documentation reste la source de vérité.

**Q : Puis-je l'utiliser avec d'autres outils d'IA que Claude ?**
Oui. La méthodologie fonctionne avec n'importe quel assistant de codage IA — copiez SKILL.md dans votre prompt système.

## Série d'articles

Ce skill condense la série en 9 parties **« Le nouveau paradigme du codage à l'ère de l'IA »** (en chinois), fondée sur 43 sources industrielles, articles académiques et retours de terrain sur le Spec-Driven Development :

- [#01 — La fin du vibe coding, c'est la planification d'abord](https://www.sagasu.art/p/vibe-coding-end-is-planning-first)
- [#02 — La spécification comme protocole : quand le document devient la source de vérité du code](https://www.sagasu.art/p/specification-is-protocol-when-document-becomes-code-fact-source)
- [#03 — La vérité sur la vitesse : ce que disent les données](https://www.sagasu.art/p/speed-truth-data-document-driven-fast-or-not)
- #04–#09 — série complète sur [sagasu.art](https://www.sagasu.art/)

## Journal des modifications

- **2026-06** — Actualisé pour l'ère des outils de codage IA / agents : types de livrables élargis, couche pont roadmap.md, principe de la colonne vertébrale architecturale, portes de validation par version, documents-comme-runtime pour les projets agentiques (principes 6-8)
- **2026-03** — Refactorisé pour l'efficacité du contexte : scindé en SKILL.md + templates.md + principles.md, ajout de la Stop Condition, déclenchement resserré
- **2026-01** — Version initiale v1.0

## Contribuer

Les contributions sont les bienvenues ! N'hésitez pas à soumettre des issues et des pull requests.

## Licence

Licence MIT — voir [LICENSE](LICENSE).

## Auteur

Créé par **SagaSu**

- Blog : <https://www.sagasu.art/>
- Twitter : [@sujingshen](https://x.com/sujingshen)

## Remerciements

Basé sur la série méthodologique « Document-Driven Development ». L'idée centrale : **la génération est bon marché, l'évolution maîtrisée est rare.**
